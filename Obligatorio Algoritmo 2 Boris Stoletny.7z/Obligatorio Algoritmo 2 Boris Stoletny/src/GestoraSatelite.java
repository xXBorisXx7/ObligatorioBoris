
import java.util.ArrayList;
import java.util.List;
import estructuras.pila.*;
import estructuras.cola.*;
import estructuras.lista.*;
import excepciones.DesbordamientoInferior;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Boris
 */
public class GestoraSatelite 
{
    private static GestoraSatelite instancia;
    private Pila<Satelite> pilaSatelite;
    private Cola<Satelite> colaSatelite;
    private Lista<Satelite> listaSatelite;
    
    private GestoraSatelite()
    {
        this.pilaSatelite = new PilaLista<Satelite>();
        this.colaSatelite = new ColaLista<Satelite>();
        this.listaSatelite = new ListaIndexada<Satelite>();
    }
    public static GestoraSatelite singleton()
    {
        if(instancia == null)
        {
            instancia = new GestoraSatelite();
            return instancia;
        }
        return instancia;
    }
    
    public void Agregar(String codigo,String nombre,int altitud)
    {
        Satelite sat = new Satelite(codigo, nombre, altitud);
        this.pilaSatelite.apilar(sat);
        this.colaSatelite.encolar(sat);
        this.listaSatelite.agregar(sat);
    }
    
    public void Borrar(String codigo) throws DesbordamientoInferior
    {
        for(int i=0; i<listaSatelite.tamanio();i++)
        {
            Satelite aux = listaSatelite.obtener(i);
            if(aux.Codigo == codigo)
            {
                listaSatelite.eliminar(aux);
            }
        }
    }
    
    public void Ver(String codigo) throws DesbordamientoInferior
    {
        for(int i = 0; i < listaSatelite.tamanio(); i++)
        {
            Satelite aux = listaSatelite.obtener(i);
            if(aux.Codigo.equals(codigo))
            {
                System.out.println(aux.toString());
            }
        }
    }
    
    public void Listar() throws DesbordamientoInferior
    {
        for(int i = 0; i < colaSatelite.tamanio(); i++)
        {
            Satelite sat = colaSatelite.desencolar();
            System.out.println(sat.toString());
        }
    }
    
    public void Tipo(String TipoOrbita) throws DesbordamientoInferior
    {
        for(int i = 0; i < pilaSatelite.tamanio(); i++)
        {
            Satelite sat = pilaSatelite.desapilar();
            if(sat.TipoOrbita.equals(TipoOrbita))
            {
                System.out.println(sat.toString());
            }
        }
    }
}
