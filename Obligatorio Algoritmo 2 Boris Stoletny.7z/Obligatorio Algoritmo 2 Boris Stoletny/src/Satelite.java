/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Boris
 */
public class Satelite 
{
    public String Codigo;
    public String Nombre;
    public int Altitud;
    public EnumOrbita TipoOrbita;

    public Satelite(String codigo, String nombre, int altitud)
    {
        Codigo = codigo;
        Nombre = nombre;
        Altitud = altitud;
        TipoOrbita = CalcularTipo(altitud);
    }

    private EnumOrbita CalcularTipo(int Altitud)
    {
        EnumOrbita Tipo = null;
        if(Altitud < 200)
        {
            Tipo = null;
        }
        else if(Altitud >= 200 && Altitud <= 2000)
        {
            Tipo = EnumOrbita.Baja;
        }
        else if(Altitud > 2000 && Altitud <= 35000)
        {
            Tipo = EnumOrbita.Media;
        }
        else if(Altitud > 35000)
        {
            Tipo = EnumOrbita.Alta;
        }
        return Tipo;
    }
    
    @Override
    public String toString()
    {
        return "Satelite: [" + Codigo + "][" + Nombre + "][" + TipoOrbita + "][" + Altitud + "]";
    }
}
