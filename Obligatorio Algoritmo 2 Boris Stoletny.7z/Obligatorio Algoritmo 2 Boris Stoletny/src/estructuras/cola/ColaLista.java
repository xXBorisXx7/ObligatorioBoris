package estructuras.cola;
import estructuras.nodos.*;
import excepciones.*;

public class ColaLista<T> implements Cola<T> {

    NodoLista<T> primero;
    NodoLista<T> ultimo;
    int tamanio;

    public ColaLista() {
        this.tamanio = 0;
        this.primero = this.ultimo = null;
    }
    
    @Override
    public void encolar(T dato) {
        if(this.esVacia()) {
            this.primero = this.ultimo = new NodoLista<>(dato, null);
        } else {
            this.ultimo = this.ultimo.siguiente = new NodoLista<>(dato, null);
        }
        this.tamanio++;
    }

    @Override
    public T desencolar() throws DesbordamientoInferior {
        if(this.esVacia()) {
            throw new DesbordamientoInferior("No hay elementos");
        }
        T res = this.primero.dato;
        this.primero = this.primero.siguiente;
        this.tamanio--;
        return res;
    }

    @Override
    public T primero() throws DesbordamientoInferior {
        if(this.esVacia()) {
            throw new DesbordamientoInferior("No hay elementos");
        }
        return this.primero.dato;
    }

    @Override
    public boolean esVacia() {
        return this.tamanio == 0;
    }

    @Override
    public void vaciar() {
        this.tamanio = 0;
        this.primero = this.ultimo = null;
    }

    @Override
    public int tamanio() {
        return this.tamanio;
    }
    
}
