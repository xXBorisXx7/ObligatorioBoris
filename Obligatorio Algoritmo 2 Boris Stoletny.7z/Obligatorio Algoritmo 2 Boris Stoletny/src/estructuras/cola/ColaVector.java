package estructuras.cola;

import excepciones.*;

public class ColaVector<T> implements Cola<T> {

    private T [] vector;
    private int primero;
    private int ultimo;
    private int tamanio;
    private final int CAPACIDAD_DEFECTO = 10;

    public ColaVector() {
        this.vector = (T []) new Object[CAPACIDAD_DEFECTO];
        this.vaciar();
    }

    public void encolar(T dato) {
        if(this.tamanio == this.vector.length) {
            this.duplicar();
        }
        this.ultimo = this.incrementar(this.ultimo);
        this.vector[this.ultimo] = dato;
        this.tamanio++;
    }

    public T desencolar() throws DesbordamientoInferior {
        if(this.esVacia()) {
            throw new DesbordamientoInferior("La pila esta vacia");
        }
        T res = this.vector[this.primero];
        this.primero = this.incrementar(this.primero);
        this.tamanio--;
        return res;
    }

    public T primero() throws DesbordamientoInferior {
        if(this.esVacia()) {
            throw new DesbordamientoInferior("La pila esta vacia");
        }
        return this.vector[this.primero];
    }

    public boolean esVacia() {
        return this.tamanio == 0;
    }

    public void vaciar() {
        this.primero = 0;
        this.ultimo = -1;
        this.tamanio = 0;
    }

    public int tamanio() {
        return this.tamanio;
    }

    public void duplicar() {
        T [] aux = (T []) new Object[this.vector.length * 2];
        for(int i = 0; i <= this.tamanio; i++) {
            this.primero = this.incrementar(this.primero);
            aux[i] = this.vector[this.primero];
        }
        this.vector = aux;
        this.primero = 0;
        this.ultimo = this.tamanio - 1;
    }

    public int incrementar(int val) {
        if(++val == this.vector.length) {
            val = 0;
        }
        return val;
    }
}
