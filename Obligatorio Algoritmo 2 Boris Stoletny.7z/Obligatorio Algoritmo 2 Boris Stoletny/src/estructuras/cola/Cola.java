package estructuras.cola;
import excepciones.*;

public interface Cola<T> {
    void encolar(T dato);
    T desencolar() throws DesbordamientoInferior;
    T primero() throws DesbordamientoInferior;
    boolean esVacia();
    void vaciar();
    int tamanio();
}
