package estructuras.pila;
import excepciones.*;

public interface Pila<T>
{

    void apilar(T obj);
    T desapilar() throws DesbordamientoInferior;//desapila y devuelve
    T cima() throws DesbordamientoInferior;//devuelve y no desapila
    boolean esVacia();
    void vaciar();
    int tamanio();

}
