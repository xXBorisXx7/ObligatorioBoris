package estructuras.pila;

import excepciones.DesbordamientoInferior;

public class PilaVector<T> implements Pila<T> {

    private T [] vector;
    private int cima;
    private final int CAPACIDAD_DEFECTO = 10;

    /**
     * Crear una nueva instancia de PilaVector
     */
    public PilaVector() {
        this.cima = -1;
        this.vector = (T []) new Object[CAPACIDAD_DEFECTO];
    }

    @Override
    public void apilar(T dato) {
        this.cima++;
        if(this.cima == this.vector.length) {
            this.duplicar();
        }
        this.vector[this.cima] = dato;
    }

    @Override
    public T desapilar() throws DesbordamientoInferior {
        if(this.esVacia()) {
            throw new DesbordamientoInferior("No hay Elementos");
        }
        return this.vector[this.cima--];
    }

    @Override
    public T cima() throws DesbordamientoInferior {
        if(this.esVacia()) {
            throw new DesbordamientoInferior("No hay Elementos");
        }
        return this.vector[this.cima];
    }

    @Override
    public boolean esVacia() {
        return this.cima == -1;
    }

    @Override
    public void vaciar() {
        this.cima = -1;
    }

    @Override
    public int tamanio() {
        return this.cima + 1;
    }
    
    /**
     * duplica la capacidad de la Pila
     */
    private void duplicar() {
        T[] aux = (T []) new Object[this.vector.length * 2];
        for(int i = 0; i < this.vector.length; i++) {
            aux[i] = this.vector[i];
        }
        this.vector = aux;
    }
}
