package estructuras.pila;
import estructuras.nodos.*;
import excepciones.*;

public class PilaLista<T> implements Pila<T> {

    private NodoLista<T> cabecera;
    private int tamanio;

    /**
     * Crear una nueva instancia de PilaLista
     */
    public PilaLista() {
        this.cabecera = null;
        this.tamanio = 0;
    }

    /**
     * Apila un nuevo elemento
     */
    public void apilar(T dato) {
        if(this.esVacia()) {
            this.cabecera = new NodoLista<>(dato, null);
        } else {
            this.cabecera = new NodoLista<>(dato, this.cabecera);
        }
        this.tamanio++;
    }

    /**
     * Desapila y retorna un elemento
     */
    public T desapilar() throws DesbordamientoInferior {
        if(this.esVacia()) {
            throw new DesbordamientoInferior("No hay Elementos");
        }

        T res = this.cabecera.dato;
        this.cabecera = this.cabecera.siguiente;
        tamanio--;
        return res;
    }

    /**
     * Retorna la cima y no desapila
     */
    public T cima() throws DesbordamientoInferior {
        if(this.esVacia()) {
            throw new DesbordamientoInferior("No hay Elementos");
        }
        return this.cabecera.dato;
    }

    /**
     * retorna verdadero si la pila esta vacia
     */
    public boolean esVacia() {
        return this.tamanio == 0;
    }

    /**
     * vacia la pila
     */
    public void vaciar() {
        this.cabecera = null;
        this.tamanio = 0;
    }

    /**
     * retorna la cantidad de elementos
     */
    public int tamanio() {
        return this.tamanio;
    }

}
