package estructuras.lista;
import estructuras.nodos.*;
import excepciones.*;

public class ListaEnlazada<T> implements Lista<T> {

    NodoLista<T> primero;
    NodoLista<T> ultimo;
    int tamanio;

    public ListaEnlazada() {
        this.tamanio = 0;
        this.primero = this.ultimo = null;
    }

    public void agregar(T dato) {
        if(this.esVacia()) {
            this.primero = this.ultimo = new NodoLista<>(dato, null);
        } else {
            this.ultimo = this.ultimo.siguiente = new NodoLista<>(dato, null);
        }
        this.tamanio++;
    }

    public void eliminar(T dato) throws DesbordamientoInferior {
        NodoLista<T> aux = this.primero;
        if(aux.dato == dato) {
            this.primero = aux.siguiente;
            this.tamanio--;
        } else {
            NodoLista<T> aux2 = this.primero;
            for(int i = 0; i < this.tamanio; i++) {
                aux = aux.siguiente;
                if(aux.dato == dato) {
                    aux2.siguiente = aux.siguiente;
                    aux.siguiente = null;
                    this.tamanio--;
                    break;
                }
                aux2 = aux2.siguiente;
            }
        }
    }

    public T obtener(int pos) throws DesbordamientoInferior {
        if(this.tamanio < (pos + 1)) {
            throw new DesbordamientoInferior("Elemento no encontrado");
        }
        NodoLista<T> aux = this.primero;
        for(int i = 0; i < pos; i++) {
            aux = aux.siguiente;
        }
        return aux.dato;
    }

    public T primero() throws DesbordamientoInferior {
        if(this.tamanio == 0) {
            throw new DesbordamientoInferior("Lista vacia");
        }
        return this.primero.dato;
    }

    public T ultimo() throws DesbordamientoInferior {
        if(this.tamanio == 0) {
            throw new DesbordamientoInferior("Lista vacia");
        }
        return this.ultimo.dato;
    }

    public int posicionDe(T dato) {
        NodoLista<T> aux = this.primero;
        for(int i = 0; i < this.tamanio; i++) {
            if(aux.dato == dato) {
                return i;
            }
            aux = aux.siguiente;
        }
        return -1;
    }

    public boolean esVacia() {
        return this.tamanio == 0;
    }

    public void vaciar() {
        this.tamanio = 0;
        this.primero = this.ultimo = null;
    }

    public int tamanio() {
        return this.tamanio;
    }
    
}
