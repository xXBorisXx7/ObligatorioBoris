package estructuras.lista;
import excepciones.*;

public interface Lista<T> {

    public void agregar(T dato);
    public void eliminar(T dato) throws DesbordamientoInferior;
    public T obtener(int pos) throws DesbordamientoInferior;
    public T primero() throws DesbordamientoInferior;
    public T ultimo() throws DesbordamientoInferior;
    public int posicionDe(T dato);
    public boolean esVacia();
    public void vaciar();
    public int tamanio();

}
