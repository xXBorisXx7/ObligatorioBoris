package estructuras.lista;

import excepciones.DesbordamientoInferior;

public class ListaIndexada<T> implements Lista<T> {

    private T[] vector;
    private int tamanio;
    private final int CAPACIDAD_DEFECTO = 10;

    public ListaIndexada() {
        this.vector = (T []) new Object[CAPACIDAD_DEFECTO];
        this.vaciar();
    }

    public void agregar(T dato) {
        if(this.tamanio == this.vector.length) {
            this.duplicar();
        }
        this.vector[this.tamanio] = dato;
        this.tamanio++;
    }

    public void eliminar(T dato) throws DesbordamientoInferior {
        int pos = this.posicionDe(dato);
        if(pos == -1) {
            throw new DesbordamientoInferior("Elemento no encontrado");
        }
        for(int i = pos; i < (this.tamanio - 1); i++) {
            this.vector[i] = this.vector[i + 1];
        }
        this.tamanio--;
    }

    public T obtener(int pos) throws DesbordamientoInferior {
        if(pos < 0 || pos > this.tamanio) {
            throw new DesbordamientoInferior("Posicion fuera de la lista");
        }
        return this.vector[pos];
    }

    public T primero() throws DesbordamientoInferior {
        if(this.esVacia()) {
            throw new DesbordamientoInferior("La lista está vacía");
        }
        return this.vector[0];
    }

    public T ultimo() throws DesbordamientoInferior {
        if(this.esVacia()) {
            throw new DesbordamientoInferior("La lista está vacía");
        }
        return this.vector[this.tamanio - 1];
    }

    public int posicionDe(T dato) {
        for(int i = 0; i < this.tamanio; i++) {
            if(this.vector[i] == dato) {
                return i;
            }
        }
        return -1;
    }

    public boolean esVacia() {
        return this.tamanio == 0;
    }

    public void vaciar() {
        this.tamanio = 0;
    }

    public int tamanio() {
        return this.tamanio;
    }

    public void duplicar() {
        T [] aux = (T []) new Object[this.vector.length * 2];
        for(int i = 0; i <= this.tamanio; i++) {
            aux[i] = this.vector[i];
        }
        this.vector = aux;
    }
}
