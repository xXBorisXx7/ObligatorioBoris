package estructuras.nodos;

public class NodoLista<T>{

    public T dato;
    public NodoLista<T> siguiente;

    public NodoLista(T dato)
    {
        this(dato, null);
    }

    public NodoLista(T dato, NodoLista<T> siguiente)
    {
        this.dato = dato;
        this.siguiente = siguiente;
    }

}
