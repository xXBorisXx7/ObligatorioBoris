
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Boris
 */
public class Main 
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        boolean entrar;
        do
        {
            entrar = true;
            String opc = scanner.nextLine();
            switch(opc)
            {
                case "salir":
                       entrar = false;
                       break;
                       
                case "agregar":
                    System.out.println("Ingrese Codigo\n");
                    String Codigo = scanner.nextLine();
                    System.out.println("Ingrese Nombre\n");
                    String Nombre = scanner.nextLine();
                    System.out.println("Ingrese Altitud\n");
                    int Altitud = Integer.parseInt(scanner.nextLine());
                    GestoraSatelite.singleton().Agregar(Codigo,Nombre,Altitud);
                    break;
                    
                case "borrar":
                    System.out.println("Ingrese Codigo\n");
                    String Codigox = scanner.nextLine();
                    System.out.println("¿Seguro? Digite si para continuar\n");
                    String confirmacion = scanner.nextLine();
                    if(confirmacion == "si")
                    {
                        GestoraSatelite.singleton().Borrar(Codigox);
                    }
                    break;
                    
                case "ver":
                    System.out.println("Ingrese Codigo\n");
                    String Codigoz = scanner.nextLine();
                    GestoraSatelite.singleton().Ver(Codigoz);
                    break;
                    
                case "listar":
                    GestoraSatelite.singleton().Listar();
                    break;
                    
                case "tipo":
                    System.out.println("Ingrese Tipo\n");
                    String Tipo = scanner.nextLine();
                    GestoraSatelite.singleton().Tipo(Tipo);
                    break;
                    
                default:
                    break;
            }
        }while(entrar);
        System.out.println("Programa Finalizado\n");
    }
}
