package excepciones;

public class DesbordamientoInferior extends Exception {

    private static final long serialVersionUID = 7745865543765204284L;

    public DesbordamientoInferior(String errorMessage) {
        super(errorMessage);
    }

}
